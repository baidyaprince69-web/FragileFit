import type { CourierSetting, Order, OrderFinancials, PackagingConfig, PackagingResult, Product, RoundingRule, Shipment } from './types.js';

export function roundChargeableWeight(weightKg: number, rule: RoundingRule): number {
  if (!Number.isFinite(weightKg) || weightKg < 0) throw new Error('Weight must be a non-negative number.');
  if (rule === 'half') return Math.ceil((weightKg - 1e-10) * 2) / 2;
  if (rule === 'one') return Math.ceil(weightKg - 1e-10);
  return Math.round(weightKg * 1000) / 1000;
}

export function calculatePackaging(
  productLines: Array<{ product: Product; quantity: number }>,
  config: PackagingConfig,
  divisor: number,
  rounding: RoundingRule = 'exact'
): PackagingResult {
  if (!Number.isFinite(divisor) || divisor <= 0) throw new Error('Courier divisor must be greater than zero.');
  if (!productLines.length) throw new Error('Add at least one product to calculate packaging.');
  const dimensions = [config.outerLengthCm, config.outerWidthCm, config.outerHeightCm];
  if (dimensions.some(v => !Number.isFinite(v) || v <= 0)) throw new Error('Outer carton dimensions must all be greater than zero.');
  const productsWeightG = productLines.reduce((sum, line) => {
    if (!Number.isInteger(line.quantity) || line.quantity < 1) throw new Error('Product quantities must be positive whole numbers.');
    return sum + line.product.actualWeightG * line.quantity;
  }, 0);
  const boxWeightG = config.outerBoxWeightG + (config.mode === 'dual' ? config.innerBoxWeightG : 0);
  const allPackagingWeightG = boxWeightG + config.innerWrapWeightG + config.cushioningWeightG;
  const actualWeightKg = (productsWeightG + allPackagingWeightG) / 1000;
  const outerVolumeCm3 = config.outerLengthCm * config.outerWidthCm * config.outerHeightCm;
  const volumetricWeightKg = outerVolumeCm3 / divisor;
  const unroundedChargeableKg = Math.max(actualWeightKg, volumetricWeightKg);
  const chargeableWeightKg = roundChargeableWeight(unroundedChargeableKg, rounding);
  const packagingCost = config.innerWrapCost + config.cushioningCost + config.protectiveWrapCost + config.otherCost;
  return { outerVolumeCm3, volumetricWeightKg, actualWeightKg, unroundedChargeableKg, chargeableWeightKg, packagingCost };
}

export function calculateOrderFinancials(order: Order, linkedShipments: Shipment[]): OrderFinancials {
  const grossRevenue = order.items.reduce((sum, item) => sum + item.quantity * item.unitSellingPrice, 0);
  const cogs = order.items.reduce((sum, item) => sum + item.quantity * item.unitProductionCost, 0);
  const orderedQuantity = order.items.reduce((sum, item) => sum + item.quantity, 0);
  const shippedQuantity = linkedShipments.reduce((sum, shipment) => sum + shipment.lines.reduce((lineSum, line) => lineSum + line.quantity, 0), 0);
  const marketplaceFees = order.marketplaceFeeType === 'percent'
    ? grossRevenue * order.marketplaceFeeValue / 100
    : order.marketplaceFeeValue;
  const paymentFees = grossRevenue * order.paymentFeePercent / 100 + order.paymentFeeFixed;

  // Use shipment actuals as the single source for fulfilment costs once shipments exist.
  // Order estimates are used only before the first linked shipment is recorded.
  const hasShipments = linkedShipments.length > 0;
  const packagingCost = hasShipments
    ? linkedShipments.reduce((sum, s) => sum + (s.actualPackagingCost ?? 0), 0)
    : order.estimatedPackagingCost;
  const shippingCost = hasShipments
    ? linkedShipments.reduce((sum, s) => sum + (s.actualShippingCost ?? 0), 0)
    : order.estimatedShippingCost;
  const actualReturnCosts = order.actualReturnCosts;
  const replacementCosts = order.replacementCosts + linkedShipments.reduce((sum, s) => sum + s.replacementCost, 0);
  const claimReimbursements = order.claimReimbursements + linkedShipments.reduce((sum, s) => sum + s.claimReimbursement, 0);
  const refunds = order.actualRefunds + linkedShipments.reduce((sum, s) => sum + s.refundAmount, 0);
  // The reserve is a planning allowance. Once the order is completed, actual return/refund records replace it.
  const returnReserve = order.status === 'Completed' ? 0 : order.returnReserve;
  const operatingCosts = cogs + packagingCost + shippingCost + marketplaceFees + paymentFees + order.directExpenses + returnReserve + actualReturnCosts + replacementCosts;
  const netRevenue = grossRevenue - refunds;
  const operatingProfit = netRevenue - operatingCosts + claimReimbursements;
  const marginPercent = grossRevenue > 0 ? operatingProfit / grossRevenue * 100 : 0;
  const taxReserve = Math.max(0, operatingProfit) * order.taxReservePercent / 100;
  const provisional = order.status !== 'Completed' || !hasShipments || shippedQuantity < orderedQuantity || linkedShipments.some(s => s.actualPackagingCost == null || s.actualShippingCost == null);
  return {
    grossRevenue, refunds, netRevenue, cogs, packagingCost, shippingCost, marketplaceFees, paymentFees,
    directExpenses: order.directExpenses, returnReserve, actualReturnCosts, replacementCosts,
    claimReimbursements, operatingCosts, operatingProfit, marginPercent, taxReserve,
    profitAfterTaxReserve: operatingProfit - taxReserve, expenseSource: hasShipments ? 'Shipment actuals' : 'Order estimates',
    provisional, shippedQuantity, orderedQuantity
  };
}

export function estimateCourierCharge(weightKg: number, courier: CourierSetting): number | null {
  if (courier.baseRate == null || courier.perKgRate == null) return null;
  const chargeable = roundChargeableWeight(weightKg, courier.rounding);
  return courier.baseRate + courier.perKgRate * chargeable;
}

export function damageRate(shipments: Shipment[]): number {
  const delivered = shipments.filter(s => s.outcome === 'Delivered safely' || s.outcome === 'Damaged' || s.outcome === 'Replaced');
  if (!delivered.length) return 0;
  return delivered.filter(s => s.outcome === 'Damaged' || s.outcome === 'Replaced').length / delivered.length * 100;
}

export function runCriticalTests(): Array<{ name: string; passed: boolean; detail: string }> {
  const results: Array<{ name: string; passed: boolean; detail: string }> = [];
  const test = (name: string, fn: () => void) => {
    try { fn(); results.push({ name, passed: true, detail: 'Passed' }); }
    catch (error) { results.push({ name, passed: false, detail: error instanceof Error ? error.message : String(error) }); }
  };
  const product: Product = { id: 'p', name: 'Test pot', sku: 'T1', category: 'Terracotta', lengthCm: 10, widthCm: 10, heightCm: 10, actualWeightG: 1000, productionCost: 100, sellingPrice: 200, notes: '', createdAt: '' };
  const config: PackagingConfig = { id: 'c', name: 'Nested test', mode: 'dual', innerLengthCm: 12, innerWidthCm: 12, innerHeightCm: 12, innerBoxWeightG: 100, outerLengthCm: 30, outerWidthCm: 25, outerHeightCm: 20, outerBoxWeightG: 300, innerWrapWeightG: 50, cushioningWeightG: 100, innerWrapCost: 10, cushioningCost: 15, protectiveWrapCost: 5, otherCost: 0, notes: '', createdAt: '' };
  test('Outer carton dimensions alone determine volumetric weight', () => {
    const a = calculatePackaging([{ product, quantity: 1 }], config, 5000);
    const modifiedInner = { ...config, innerLengthCm: 100, innerWidthCm: 100, innerHeightCm: 100 };
    const b = calculatePackaging([{ product, quantity: 1 }], modifiedInner, 5000);
    if (a.volumetricWeightKg !== 3 || b.volumetricWeightKg !== 3) throw new Error(`Expected 3kg from outer carton; got ${a.volumetricWeightKg} and ${b.volumetricWeightKg}`);
  });
  test('Dual-box tare and protective material weight are included in actual weight', () => {
    const result = calculatePackaging([{ product, quantity: 1 }], config, 5000);
    if (Math.abs(result.actualWeightKg - 1.55) > 1e-9) throw new Error(`Expected 1.55kg; got ${result.actualWeightKg}`);
  });
  test('Multi-line order revenue, COGS and fees aggregate', () => {
    const order: Order = { id: 'o', orderNumber: 'O-1', date: '', status: 'Pending', items: [
      { id: '1', productId: 'p', productName: 'Pot', quantity: 2, unitProductionCost: 100, unitSellingPrice: 250, unitWeightG: 0 },
      { id: '2', productId: 'm', productName: 'Mug', quantity: 3, unitProductionCost: 50, unitSellingPrice: 100, unitWeightG: 0 }
    ], marketplaceFeeType: 'percent', marketplaceFeeValue: 10, paymentFeePercent: 2, paymentFeeFixed: 5, estimatedPackagingCost: 20, estimatedShippingCost: 30, directExpenses: 0, returnReserve: 0, actualRefunds: 0, actualReturnCosts: 0, replacementCosts: 0, claimReimbursements: 0, taxReservePercent: 0, notes: '', createdAt: '' };
    const f = calculateOrderFinancials(order, []);
    if (f.grossRevenue !== 800 || f.cogs !== 350 || f.marketplaceFees !== 80 || f.paymentFees !== 21) throw new Error(`Unexpected totals: ${JSON.stringify(f)}`);
  });
  test('Multiple shipment expenses roll up without using order estimates', () => {
    const order: Order = { id: 'o', orderNumber: 'O-2', date: '', status: 'Completed', items: [{ id: '1', productId: 'p', productName: 'Pot', quantity: 2, unitProductionCost: 50, unitSellingPrice: 200, unitWeightG: 0 }], marketplaceFeeType: 'fixed', marketplaceFeeValue: 0, paymentFeePercent: 0, paymentFeeFixed: 0, estimatedPackagingCost: 999, estimatedShippingCost: 999, directExpenses: 0, returnReserve: 0, actualRefunds: 0, actualReturnCosts: 0, replacementCosts: 0, claimReimbursements: 0, taxReservePercent: 0, notes: '', createdAt: '' };
    const shipments: Shipment[] = [
      { id: 's1', trackingRef: '1', orderId: 'o', lines: [], courierName: 'Test', mode: 'Surface', divisor: 4000, dispatchDate: '', outcome: 'Delivered safely', actualShippingCost: 40, actualPackagingCost: 12, damageCategory: '', damageLoss: 0, replacementCost: 0, refundAmount: 0, claimStatus: 'None', claimReimbursement: 0, notes: '', createdAt: '' },
      { id: 's2', trackingRef: '2', orderId: 'o', lines: [], courierName: 'Test', mode: 'Air Express', divisor: 5000, dispatchDate: '', outcome: 'Delivered safely', actualShippingCost: 60, actualPackagingCost: 18, damageCategory: '', damageLoss: 0, replacementCost: 0, refundAmount: 0, claimStatus: 'None', claimReimbursement: 0, notes: '', createdAt: '' }
    ];
    const f = calculateOrderFinancials(order, shipments);
    if (f.packagingCost !== 30 || f.shippingCost !== 100) throw new Error(`Expected shipment actuals 30/100, got ${f.packagingCost}/${f.shippingCost}`);
  });
  test('Weight rounding follows half-kilogram and one-kilogram rules', () => {
    if (roundChargeableWeight(1.01, 'half') !== 1.5 || roundChargeableWeight(1.01, 'one') !== 2) throw new Error('Rounding output did not match expected values.');
  });
  test('Partially fulfilled orders remain provisional', () => {
    const order: Order = { id: 'partial', orderNumber: 'O-P', date: '', status: 'Completed', items: [{ id: '1', productId: 'p', productName: 'Pot', quantity: 3, unitProductionCost: 10, unitSellingPrice: 20, unitWeightG: 0 }], marketplaceFeeType: 'fixed', marketplaceFeeValue: 0, paymentFeePercent: 0, paymentFeeFixed: 0, estimatedPackagingCost: 0, estimatedShippingCost: 0, directExpenses: 0, returnReserve: 0, actualRefunds: 0, actualReturnCosts: 0, replacementCosts: 0, claimReimbursements: 0, taxReservePercent: 0, notes: '', createdAt: '' };
    const parcel: Shipment = { id: 's', trackingRef: 'S', orderId: 'partial', lines: [{ productId: 'p', productName: 'Pot', quantity: 1, unitWeightG: 0 }], courierName: 'Test', mode: 'Surface', divisor: 4000, dispatchDate: '', outcome: 'Delivered safely', actualShippingCost: 10, actualPackagingCost: 5, damageCategory: '', damageLoss: 0, replacementCost: 0, refundAmount: 0, claimStatus: 'None', claimReimbursement: 0, notes: '', createdAt: '' };
    if (!calculateOrderFinancials(order, [parcel]).provisional) throw new Error('An order with unshipped quantity must remain provisional.');
  });
  return results;
}
