import { getAllData, replaceAllData } from './db.js';
import { decryptBackupText, encryptBackupText } from './security.js';
import type { AppData } from './types.js';

function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url; link.download = filename; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function exportPlainBackup(): Promise<void> {
  const data = await getAllData();
  const payload = { format: 'FragileFit JSON backup', version: 1, exportedAt: new Date().toISOString(), data };
  downloadBlob(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }), `fragilefit-backup-${new Date().toISOString().slice(0, 10)}.json`);
}

export async function exportEncryptedBackup(password: string): Promise<void> {
  const data = await getAllData();
  const plaintext = JSON.stringify({ format: 'FragileFit JSON backup', version: 1, exportedAt: new Date().toISOString(), data });
  const encrypted = await encryptBackupText(plaintext, password);
  downloadBlob(new Blob([encrypted], { type: 'application/octet-stream' }), `fragilefit-${new Date().toISOString().slice(0, 10)}.fragilefit.enc`);
}

export async function importBackupFile(file: File, password?: string): Promise<void> {
  const raw = JSON.parse(await file.text()) as Record<string, unknown>;
  let payload: { data: AppData; version: number };
  if (raw.format === 'FRAGILEFIT-ENCRYPTED-BACKUP') {
    if (!password) throw new Error('Enter the password used to encrypt this backup.');
    const plaintext = await decryptBackupText(JSON.stringify(raw), password);
    payload = JSON.parse(plaintext) as typeof payload;
  } else if (raw.format === 'FragileFit JSON backup') {
    payload = raw as unknown as typeof payload;
  } else {
    throw new Error('This file is not a recognised FragileFit backup.');
  }
  const data = payload.data;
  if (payload.version !== 1 || !data || !Array.isArray(data.products) || !Array.isArray(data.orders) || !Array.isArray(data.shipments) || !Array.isArray(data.packaging) || !Array.isArray(data.couriers) || !data.settings) {
    throw new Error('Backup structure is incomplete or unsupported.');
  }
  await replaceAllData(data);
}
