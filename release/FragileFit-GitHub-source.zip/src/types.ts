export type Category = 'Terracotta' | 'Ceramic' | 'Glassware' | 'Candle' | 'Handicraft' | 'Home decor' | 'Other';
export type CourierMode = 'Surface' | 'Air Express' | 'Standard';
export type RoundingRule = 'exact' | 'half' | 'one';
export type ShipmentOutcome = 'Dispatched' | 'Delivered safely' | 'Damaged' | 'Returned' | 'Replaced';
export type ClaimStatus = 'None' | 'Submitted' | 'Reimbursed';
export type OrderStatus = 'Pending' | 'Partially fulfilled' | 'Completed' | 'Cancelled';

export interface Product {
  id: string; name: string; sku: string; category: Category;
  lengthCm: number; widthCm: number; heightCm: number; actualWeightG: number;
  productionCost: number; sellingPrice: number; preferredPackagingId?: string; notes: string;
  isSample?: boolean; createdAt: string;
}

export interface PackagingConfig {
  id: string; name: string; mode: 'single' | 'dual';
  innerLengthCm: number; innerWidthCm: number; innerHeightCm: number; innerBoxWeightG: number;
  outerLengthCm: number; outerWidthCm: number; outerHeightCm: number; outerBoxWeightG: number;
  innerWrapWeightG: number; cushioningWeightG: number;
  innerWrapCost: number; cushioningCost: number; protectiveWrapCost: number; otherCost: number;
  notes: string; isSample?: boolean; createdAt: string;
}

export interface OrderLine {
  id: string; productId: string; productName: string; quantity: number;
  unitProductionCost: number; unitSellingPrice: number; unitWeightG: number;
}

export interface Order {
  id: string; orderNumber: string; date: string; status: OrderStatus; items: OrderLine[];
  marketplaceFeeType: 'percent' | 'fixed'; marketplaceFeeValue: number;
  paymentFeePercent: number; paymentFeeFixed: number;
  estimatedPackagingCost: number; estimatedShippingCost: number; directExpenses: number;
  returnReserve: number; actualRefunds: number; actualReturnCosts: number;
  replacementCosts: number; claimReimbursements: number; taxReservePercent: number;
  notes: string; isSample?: boolean; createdAt: string;
}

export interface ShipmentLine { productId: string; productName: string; quantity: number; unitWeightG: number; }
export interface Shipment {
  id: string; trackingRef: string; orderId?: string; lines: ShipmentLine[];
  packagingConfigId?: string; courierId?: string; courierName: string; mode: CourierMode;
  divisor: number; dispatchDate: string; deliveryDate?: string; outcome: ShipmentOutcome;
  actualShippingCost?: number; actualPackagingCost?: number; chargeableWeightKg?: number;
  damageCategory: string; damageLoss: number; replacementCost: number;
  refundAmount: number; claimStatus: ClaimStatus; claimReimbursement: number;
  notes: string; isSample?: boolean; createdAt: string;
}

export interface CourierSetting {
  id: string; name: string; mode: CourierMode; divisor: number;
  baseRate?: number; perKgRate?: number; rounding: RoundingRule;
  isPreset?: boolean; isSample?: boolean;
}

export interface AppSettings { businessName: string; currency: string; unitSystem: 'metric'; theme: 'dark'; }
export interface AppData {
  products: Product[]; packaging: PackagingConfig[]; orders: Order[];
  shipments: Shipment[]; couriers: CourierSetting[]; settings: AppSettings;
}

export interface PackagingResult {
  outerVolumeCm3: number; volumetricWeightKg: number; actualWeightKg: number;
  unroundedChargeableKg: number; chargeableWeightKg: number; packagingCost: number;
}

export interface OrderFinancials {
  grossRevenue: number; refunds: number; netRevenue: number; cogs: number;
  packagingCost: number; shippingCost: number; marketplaceFees: number;
  paymentFees: number; directExpenses: number; returnReserve: number;
  actualReturnCosts: number; replacementCosts: number; claimReimbursements: number;
  operatingCosts: number; operatingProfit: number; marginPercent: number;
  taxReserve: number; profitAfterTaxReserve: number; expenseSource: 'Shipment actuals' | 'Order estimates';
  provisional: boolean; shippedQuantity: number; orderedQuantity: number;
}
