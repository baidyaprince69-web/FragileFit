# FragileFit

**Packaging Intelligence & Profitability Platform**  
Pack smarter. Ship safer. Keep more profit.

FragileFit is an offline-first business workspace for small sellers of fragile products such as terracotta, ceramics, glassware, candles and artisan decor.

## What is included in this first release

- **Dashboard:** live metrics from saved products, orders and shipments.
- **Product catalogue:** product dimensions, actual weight, production costs, selling prices and preferred packaging.
- **Packaging recipes:** single-box and nested dual-box configurations, inner/outer tare weights, cushioning and material costs.
- **Packaging calculator:** actual vs volumetric weight, configurable courier divisors and chargeable-weight rounding.
- **Orders ledger:** multi-line orders, fee structures, returns, reserves, tax provision and order-level profit calculations.
- **Split shipments:** multiple parcels linked to one order, independent parcel contents, status, courier and actual costs.
- **Damage log:** incident categories, damage losses, refunds, replacement costs and claim reimbursements.
- **Packaging intelligence:** rule-based comparisons from the business's own shipment data; comparisons with fewer than 10 resolved observations are marked insufficient.
- **Reports:** CSV export, plain JSON backup, AES-256-GCM encrypted backup and restore, printable summary.
- **Settings:** business name, INR/USD/EUR/GBP, editable generic courier presets and custom courier rules.
- **PWA:** installable web app shell with offline caching for the core application.
- **In-app checks:** calculator, shipment allocation and encryption tests.

All preloaded data is clearly marked **SAMPLE DATA**. The sample financial figures are illustrative, not actual courier tariffs, marketplace prices or tested damage rates. Courier rates start blank and must be entered from the seller's own agreement.

## Important calculation rules

1. Courier volumetric weight uses **only the final outer carton's external dimensions**: `outer length × outer width × outer height ÷ courier divisor`.
2. Inner-box volume is never added to outer-box volume.
3. Actual shipment weight includes product weight, inner/outer box tare weights and recorded protective-material weights.
4. Orders can contain multiple product lines. Shipments can contain partial quantities and multiple shipments can fulfil one order.
5. Order-level estimated packaging/shipping is used only before any shipment is linked. After a shipment is linked, linked shipment costs are the source for packaging and shipping; order estimates are not added again.
6. An order remains provisional while it is not completed, linked shipment costs are missing, or the total shipped quantity is below the ordered quantity.
7. Refunds reduce revenue. Actual return/replacement expenses and claim reimbursements are tracked separately. Tax reserve is displayed separately from operating profit.

## Technology choices

This first release is a **dependency-light, framework-free TypeScript PWA** rather than a React/Vite bundle. It uses native browser APIs so the public app can be hosted as static files on GitHub Pages without a paid backend, third-party database, paid AI API or build server.

- TypeScript source: `src/`
- Browser JavaScript modules: `assets/`
- Local structured storage: IndexedDB
- Backup encryption: PBKDF2-HMAC-SHA-256 (100,000 iterations) + AES-256-GCM through Web Crypto
- Offline shell: `sw.js`
- Deployment: GitHub Pages Actions workflow in `.github/workflows/deploy.yml`

The compiled browser modules are included in `assets/`, so GitHub Pages can serve the app directly. If you edit TypeScript source, rebuild the JavaScript modules before publishing.

## Run locally

Use Node.js 20+ and TypeScript 5.8+.

```bash
npm install
npm run build
npm test
```

Serve the project over localhost (required for service-worker and Web Crypto testing):

```bash
python -m http.server 8000
```

Open `http://localhost:8000`.

The `npm test` command compiles the TypeScript modules and runs the calculation and encryption checks in `tests/run-tests.mjs`.

## Publish with GitHub Pages

1. Create a new **public** GitHub repository named `FragileFit` under your account. Initialize it with a README so that the `main` branch exists.
2. Upload the contents of this project to the repository root, including the hidden `.github/workflows/deploy.yml` file.
3. In the repository, open **Settings → Pages** and set the publishing source to **GitHub Actions**.
4. Push to `main`. The workflow uploads the static site and deploys it to GitHub Pages.
5. Check the repository's **Actions** tab for the deployment result. The Pages URL will be shown in the deployment job.

GitHub's current Pages workflow documentation: https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages

## Data and privacy notes

- Business records stay in the current browser profile's IndexedDB database.
- No account, bank connection or cloud server is required.
- Clearing browser data or uninstalling/resetting the browser can remove local records. Export a backup regularly.
- Plain JSON backups are **not encrypted**. Encrypted backups use a password-derived key. Keep the password safe; it cannot be recovered.
- Use HTTPS (GitHub Pages provides HTTPS) for secure-context features such as service workers and Web Crypto.
- This tool provides estimates based on user-entered values. It is not a courier tariff source, accounting system, tax adviser or guarantee of packaging safety.

## Current limitations / next development steps

- No cloud accounts or cross-device synchronisation.
- No courier, marketplace or payment-provider API integrations.
- Shipping charges are estimated only when the user enters their actual base and per-kg rates; otherwise they remain manual.
- Product/order/shipment records are entered manually. CSV import and stock-level accounting can be added later.
- Product photos and evidence-image attachment are not part of this initial core release.
- Packaging intelligence is intentionally rule-based and does not claim laboratory testing or predictive AI.

## License

No open-source license has been selected yet. Do not assume the project is licensed for reuse or redistribution; choose a license before inviting outside contributors or commercial distribution.
