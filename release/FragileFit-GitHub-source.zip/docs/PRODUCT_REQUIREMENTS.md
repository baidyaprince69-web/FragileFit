# FragileFit product requirements — initial release

## Product goal

Give fragile-goods sellers a single local workspace for product costing, packaging calculations, order profitability, parcel tracking and evidence-led packaging comparisons.

## Core entities

- **Product:** identity, category, measurements, actual weight, production cost and sale price.
- **Packaging configuration:** single or dual-box mode, inner box, final outer carton, protective-material weights and material costs.
- **Order:** separate record with multiple product line items, fee settings, estimates, refunds, return/replacement costs, reimbursements and tax provision.
- **Shipment:** independent parcel linked to an order or recorded as standalone; parcel line items allow partial fulfilment and split dispatches.
- **Courier setting:** editable mode, divisor, optional seller-entered base/per-kg charges and rounding rule.

## Required calculation behaviour

1. Outer carton volume = external outer length × external outer width × external outer height.
2. Volumetric weight = outer carton volume ÷ the selected courier divisor.
3. Inner-box volume is never added to outer carton volume.
4. Actual packaged weight = product line weights + applicable box tare weights + recorded protective-material weights.
5. Chargeable weight is the greater of actual and volumetric weight, then the selected courier rounding rule is applied.
6. Gross order revenue and manufacturing cost aggregate across every product line and quantity.
7. Order packaging/shipping estimates are used only before linked shipments exist. Once shipments exist, linked shipment packaging/shipping expense fields are the source; estimates are not also added.
8. An order is provisional if it is not marked complete, has no linked shipment, has unshipped quantity, or has a linked shipment without an actual packaging or shipping amount.
9. Refunds reduce net revenue. Actual return costs, replacement costs and claim reimbursements remain separate line items.
10. Tax reserve is calculated separately from operating profit.

## Security and data

- Browser IndexedDB is the first-release persistence layer.
- The application has no account or cloud sync.
- Plain JSON export is explicitly unencrypted.
- Encrypted backups use PBKDF2-SHA-256 with random salt and AES-256-GCM with random IV through Web Crypto.
- Sample records are labeled and resettable.
- Core calculations and records should continue to work offline after the app shell has been cached.

## Intelligence limitations

Packaging intelligence must use recorded shipment data and visible rules. It must not invent courier tariffs, claim laboratory validation, or produce apparently reliable damage comparisons from tiny samples. Fewer than 10 resolved observations are labelled insufficient for rate comparison.
