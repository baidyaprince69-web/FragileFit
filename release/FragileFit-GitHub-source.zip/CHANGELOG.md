# Changelog

## 0.1.0 — Initial core release

- Added local IndexedDB storage and labelled demo records.
- Added product catalogue and single/dual-box packaging recipes.
- Added outer-carton-only volumetric weight calculator.
- Added multi-line order economics and separate shipment records for split fulfilment.
- Added editable generic courier divisors and optional user-entered freight rates.
- Added damage, refund, replacement and reimbursement records.
- Added rule-based packaging comparisons with minimum-observation guardrail.
- Added CSV, plain JSON and PBKDF2/AES-GCM encrypted backup/restore.
- Added calculation and encryption tests, PWA manifest, service worker and GitHub Pages workflow.
